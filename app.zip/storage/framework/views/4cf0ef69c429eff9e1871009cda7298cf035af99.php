

<?php $__env->startSection('header'); ?>
<style>
	#intro {
		background-image: url('../images/bg-pic.jpg');
        height: 50vh;
	}

    @media (min-width: 992px) {
		#intro {
          	margin-top: 0px;
        }
    }

	.navbar .nav-link {
		color: #fff !important;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2>Login</h2>
	<p>Use the Log in details found in your email to access the application form</p>
	<div id="intro" class="bg-image shadow-2-strong">
		<div class="mask d-flex align-items-center h-100" style="background-color: rgba(0, 0, 0, 0.8);">
	        <div class="container">
	          	<div class="row justify-content-center">
	            	<div class="col-xl-5 col-md-8">
	              		<form class="bg-white  rounded-5 shadow-5-strong p-5" action="" method="post">
	              			<?php echo csrf_field(); ?>
	                		<div class="form-outline mb-4">
	                  			<input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>"/>
	                  			<label class="form-label" for="email">Email address</label>
	                  			<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div style="color:red"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                		</div>
			                <div class="form-outline mb-4">
			                  	<input type="password" id="password" name="password" class="form-control" />
			                  	<label class="form-label" for="password">Password</label>
			                  	<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div style="color:red"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                </div>
	                		<button type="submit" class="btn btn-primary btn-block">Sign in</button>
	              		</form>
	              		<?php if(session('error')): ?>
							<div style="color:red"><?php echo e(session('error')); ?></div>
						<?php endif; ?>
	            	</div>
	          	</div>
	        </div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\laravel\resources\views/application/login.blade.php ENDPATH**/ ?>