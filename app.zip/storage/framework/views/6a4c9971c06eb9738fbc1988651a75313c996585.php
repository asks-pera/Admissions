

<?php $__env->startSection('navigation'); ?>
    <a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('admin')); ?>">Back</a>
    <a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('admin/logout')); ?>">Logout</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2>Select record to change</h2>
	<div style="padding-left:3em">
	<?php $__currentLoopData = $setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h3><a href="<?php echo e(route('settings.edit', $item['id'])); ?>"><?php echo e($item['name']); ?></a> for <?php echo e($item['year']); ?></h3>
		<ul>
			<li><?php echo e($item['open']); ?></li>
			<li><?php echo e($item['close']); ?></li>
		</ul>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<div style="text-align: right"><p><a href="<?php echo e(route('settings.create')); ?>">Create Item</a></p></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/admin/settings/view.blade.php ENDPATH**/ ?>