

<?php $__env->startSection('navigation'); ?>
	<?php if($state != 'Application Submitted'): ?>
		<form action="<?php echo e(url('application/logout')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="guard" value="user"/>
			<button class="btn btn-primary btn-primary">Logout</button>
		</form>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2 class="text-center">Welcome to the Online Application form for student admission to S. Thomas' College, Mount Lavinia</h2><br/>
	<p class="text-center alert alert-info">Current Status of the Application Form - <strong><?php echo e($state); ?></strong></p>
	<div class="border p-3 h-100">
		<ol>
			<li><div class="row pl-3 ml-3"><div class="col-sm">Purchase Application</div>
				<?php if(!$status['purchased']): ?>
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/formpurchase?id=' . $status['id'] . '')); ?>">Purchase Application</a></div>
				<?php else: ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"></div>
				<?php endif; ?>
				</div>
			</li>
			<li><div class="row pl-3 ml-3"><div class="col-sm">Child's Details</div>
				<?php if($status['purchased'] && !$status['submitted'] && !$status['child']): ?>
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/child?id=' . $status['id'] . '')); ?>">Enter Child's Details</a></div>
				<?php elseif($status['purchased'] && !$status['submitted'] && $status['child']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/child?id=' . $status['id'] . '')); ?>">Update Child's Details</a></div>
				<?php elseif($status['purchased'] && $status['submitted']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"></div>
				<?php else: ?>
					<div class="col-sm alert alert-danger text-center">Incompleted</div>
					<div class="col-sm text-center"></div>
				<?php endif; ?>
				</div>
			</li>
			<li><div class="row pl-3 ml-3"><div class="col-sm">Father's Details</div>
				<?php if($status['purchased'] && !$status['submitted'] && !$status['father']): ?>
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/father?id=' . $status['id'] . '')); ?>">Enter Father's Details</a></div>
				<?php elseif($status['purchased'] && !$status['submitted'] && $status['father']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/father?id=' . $status['id'] . '')); ?>">Update Father's Details</a></div>
				<?php elseif($status['purchased'] && $status['submitted']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"></div>
				<?php else: ?> 
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"></div>
				<?php endif; ?>
				</div>
			</li>
			<li><div class="row pl-3 ml-3"><div class="col-sm">Mother's Details</div>
				<?php if($status['purchased'] && !$status['submitted'] && !$status['mother']): ?>
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/mother?id=' . $status['id'] . '')); ?>">Enter Mother's Details</a></div>
				<?php elseif($status['purchased'] && !$status['submitted'] && $status['mother']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/mother?id=' . $status['id'] . '')); ?>">Update Mother's Details</a></div>
				<?php elseif($status['purchased'] && $status['submitted']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"></div>
				<?php else: ?> 
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"></div>
				<?php endif; ?>
				</div>
			</li>
			<li><div class="row pl-3 ml-3"><div class="col-sm">Details of other Children</div>
				<?php if($status['purchased'] && !$status['submitted'] && !$status['other']): ?>
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/other?id=' . $status['id'] . '')); ?>">Enter details of other children</a></div>
				<?php elseif($status['purchased'] && !$status['submitted'] && $status['other']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/other?id=' . $status['id'] . '')); ?>">Update details of other children</a></div>
				<?php elseif($status['purchased'] && $status['submitted']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"></div>
				<?php else: ?> 
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"></div>
				<?php endif; ?>
				</div>
			</li>
			<?php if(($section == "ALevels") || ($section == "Grade 6") || ($section == "Branch Schools")): ?>
				<li><div class="row pl-3 ml-3"><div class="col-sm">Exam Results</div>
					<?php if($status['purchased'] && !$status['submitted'] && !$status['results']): ?>
						<div class="col-sm alert alert-danger text-center">Incomplete</div>
						<div class="col-sm text-center"><a href="<?php echo e(url('/application/results?id=' . $status['id'] . '')); ?>">Enter Exam Results</a></div>
					<?php elseif($status['purchased'] && !$status['submitted'] && $status['results']): ?>
						<div class="col-sm alert alert-success text-center">Completed</div>
						<div class="col-sm text-center"><a href="<?php echo e(url('/application/results?id=' . $status['id'] . '')); ?>">Update Exam Results</a></div>
					<?php elseif($status['purchased'] && $status['submitted']): ?>
						<div class="col-sm alert alert-success text-center">Completed</div>
						<div class="col-sm text-center"></div>
					<?php else: ?> 
						<div class="col-sm alert alert-danger text-center">Incomplete</div>
						<div class="col-sm text-center"></div>
					<?php endif; ?>
					</div>
				</li>
			<?php endif; ?>
			<?php if(($section == "Branch Schools") || ($section == "ALevels")): ?>
				<li><div class="row pl-3 ml-3"><div class="col-sm">Subject Choices</div>
					<?php if($status['purchased'] && !$status['submitted'] && !$status['subjects']): ?>
						<div class="col-sm alert alert-danger text-center">Incomplete</div>
						<div class="col-sm text-center"><a href="<?php echo e(url('/application/subjects?id=' . $status['id'] . '')); ?>">Enter Subject Choices</a></div>
					<?php elseif($status['purchased'] && !$status['submitted'] && $status['subjects']): ?>
						<div class="col-sm alert alert-success text-center">Completed</div>
						<div class="col-sm text-center"><a href="<?php echo e(url('/application/subjects?id=' . $status['id'] . '')); ?>">Update Subject Choices</a></div>
					<?php elseif($status['purchased'] && $status['submitted']): ?>
						<div class="col-sm alert alert-success text-center">Completed</div>
						<div class="col-sm text-center"></div>
					<?php else: ?> 
						<div class="col-sm alert alert-danger text-center">Incomplete</div>
						<div class="col-sm text-center"></div>
					<?php endif; ?>
					</div>
				</li>
			<?php endif; ?>
			<?php if($religion == 'Christian'): ?>
				<li><div class="row pl-3 ml-3"><div class="col-sm">Church Details</div>
					<?php if($status['purchased'] && !$status['submitted'] && !$status['church']): ?>
						<div class="col-sm alert alert-danger text-center">Incomplete</div>
						<div class="col-sm text-center"><a href="<?php echo e(url('/application/church?id=' . $status['id'] . '')); ?>">Enter Church Details</a></div>
					<?php elseif($status['purchased'] && !$status['submitted'] && $status['church']): ?>
						<div class="col-sm alert alert-success text-center">Completed</div>
						<div class="col-sm text-center"><a href="<?php echo e(url('/application/church?id=' . $status['id'] . '')); ?>">Update Church Details</a></div>
					<?php elseif($status['purchased'] && $status['submitted']): ?>
						<div class="col-sm alert alert-success text-center">Completed</div>
						<div class="col-sm text-center"></div>
					<?php else: ?> 
						<div class="col-sm alert alert-danger text-center">Incomplete</div>
						<div class="col-sm text-center"></div>
					<?php endif; ?>
					</div>
				</li>
			<?php endif; ?>
			<?php if($oba == 1): ?>
				<li><div class="row pl-3 ml-3"><div class="col-sm">OBA Details</div>
					<?php if($status['purchased'] && !$status['submitted'] && !$status['oba']): ?>
						<div class="col-sm alert alert-danger text-center">Incomplete</div>
						<div class="col-sm text-center"><a href="<?php echo e(url('/application/oba?id=' . $status['id'] . '')); ?>">Enter OBA Details</a></div>
					<?php elseif($status['purchased'] && !$status['submitted'] && $status['oba']): ?>
						<div class="col-sm alert alert-success text-center">Completed</div>
						<div class="col-sm text-center"><a href="<?php echo e(url('/application/oba?id=' . $status['id'] . '')); ?>">Update OBA Details</a></div>
					<?php elseif($status['purchased'] && $status['submitted']): ?>
						<div class="col-sm alert alert-success text-center">Completed</div>
						<div class="col-sm text-center"></div>
					<?php else: ?> 
						<div class="col-sm alert alert-danger text-center">Incomplete</div>
						<div class="col-sm text-center"></div>
					<?php endif; ?>
					</div>
				</li>
			<?php endif; ?>
			<li><div class="row pl-3 ml-3"><div class="col-sm">STC Staff Details</div>
				<?php if($status['purchased'] && !$status['submitted'] && !$status['staff']): ?>
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/staff?id=' . $status['id'] . '')); ?>">Enter Staff Details</a></div>
				<?php elseif($status['purchased'] && !$status['submitted'] && $status['staff']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/staff?id=' . $status['id'] . '')); ?>">Update Staff Details</a></div>
				<?php elseif($status['purchased'] && $status['submitted']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"></div>
				<?php else: ?> 
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"></div>
				<?php endif; ?>
				</div>
			</li>
			<li><div class="row pl-3 ml-3"><div class="col-sm">Connections</div>
				<?php if($status['purchased'] && !$status['submitted'] && !$status['connections']): ?>
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/connections?id=' . $status['id'] . '')); ?>">Enter Connections</a></div>
				<?php elseif($status['purchased'] && !$status['submitted'] && $status['connections']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/connections?id=' . $status['id'] . '')); ?>">Update Connections</a></div>
				<?php elseif($status['purchased'] && $status['submitted']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"></div>
				<?php else: ?> 
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"></div>
				<?php endif; ?>
				</div>
			</li>
			<li><div class="row pl-3 ml-3"><div class="col-sm">General Information</div>
				<?php if($status['purchased'] && !$status['submitted'] && !$status['general']): ?>
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/general?id=' . $status['id'] . '')); ?>">Enter General Information</a></div>
				<?php elseif($status['purchased'] && !$status['submitted'] && $status['general']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/general?id=' . $status['id'] . '')); ?>">Update General Information</a></div>
				<?php elseif($status['purchased'] && $status['submitted']): ?>
					<div class="col-sm alert alert-success text-center">Completed</div>
					<div class="col-sm text-center"></div>
				<?php else: ?> 
					<div class="col-sm alert alert-danger text-center">Incomplete</div>
					<div class="col-sm text-center"></div>
				<?php endif; ?>
				</div>
			</li>
			<li><div class="row pl-3 ml-3"><div class="col-sm">Submit</div>
				<?php if($submit == 0): ?>
					<div class="col-sm alert alert-danger text-center">Some sections remain incomplete</div>
					<div class="col-sm text-center"></div>
				<?php elseif($submit == 1): ?>
					<div class="col-sm alert alert-danger text-center">All sections complete - Form to be submitted</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/submit?id=' . $status['id'] . '')); ?>">Review & Submit Application</a></div>
				<?php elseif($submit == 99): ?>
					<div class="col-sm alert alert-success text-center">Application has already been submitted</div>
					<div class="col-sm text-center"><a href="<?php echo e(url('/application/finalised?id=' . $status['id'] . '')); ?>">View Completed Application</a></div>
				<?php endif; ?>
				</div>
			</li>
		</ol>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\laravel\resources\views/application/status.blade.php ENDPATH**/ ?>