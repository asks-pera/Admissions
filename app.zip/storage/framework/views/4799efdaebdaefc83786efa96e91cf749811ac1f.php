

<?php $__env->startSection('navigation'); ?>
	<a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('application/status')); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('year'); ?>
	- <?php echo e($year); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div id="student_picture"><img src="<?php echo e(url('/uploads/' . $picture . '')); ?>" height='120' alt="" style='float:right' /></div>
	<h2>Church Details</h2>
	<form action="" method="post" border="1px border grey">
		<?php echo csrf_field(); ?>
		<input type="hidden" value="<?php echo e($id); ?>" name="id" />
		<div class = "form-group row" style="padding-bottom: 20px;">
			<label class="col-md-4 col-form-label" for="parish">* Name of the Parish</label>
			<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Enter name of the parish you attend" id="parish" name="parish" value="<?php if(isset($church)): ?><?php echo e($church['parish']); ?><?php else: ?><?php echo e(old('parish')); ?><?php endif; ?>"/></div>
			<?php $__errorArgs = ['parish'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="col-md-4"></div>
				<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div class = "form-group row" style="padding-bottom: 20px;">
			<label class="col-md-4 col-form-label" for="priest">* Name and address of the Parish Priest</label>
			<div class="col-md-8"><input class="form-control" type="text" maxlength="200" placeholder="Enter name and address of the Parish Priest" id="priest" name="priest" value="<?php if(isset($church)): ?><?php echo e($church['priest']); ?><?php else: ?><?php echo e(old('priest')); ?><?php endif; ?>" /></div>
			<?php $__errorArgs = ['priest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="col-md-4"></div>
				<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div class="row" style="margin-top:10px; ">
			<div class="col-md-6 text-center"><a class="btn btn-primary btn-lg" style="margin:10px 0;" type="button" href="<?php echo e(url('application/status')); ?>">Back</a></div>
			<div class="col-md-6 text-center"><input class="btn btn-primary btn-lg" style="margin:10px 0;" type="submit" <?php if(!isset($church)): ?> value="Save Data" <?php else: ?> value="Update Data" <?php endif; ?> id="cmdSave" name="cmdSave"/></div>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/application/church.blade.php ENDPATH**/ ?>