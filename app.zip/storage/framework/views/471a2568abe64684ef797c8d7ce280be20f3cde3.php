<div>
	<img src="https://admissions.stcmount.com/images/crest2.png" alt='Missing Crest' height="100px"/>
	<h1>S. Thomas' College, Mount, Lavinia - Admissions</h1><br/>
	<p>Dear Mr/Mrs/Rev <?php echo e($applicant['name']); ?>,</p>
	<p>Thank you for your interest in purchasing an e-application form for the <?php echo e($applicant['section']); ?> Admission. Please access the application form using the following link and the given username and password, purchase, complete and submit the application form for consideration for admission to S. Thomas' College, Mount Lavinia.</p>
	<div style="margin-left:3em">WebLink : <a href="https://admissions.stcmount.com/application/login">Access Application</a></div>
	<div style="margin-left:3em">Username : <?php echo e($applicant['email']); ?></div>
	<div style="margin-left:3em">Password : <?php echo e($password); ?></div><br/><br/>
	<div style="color:red">PLEASE DO NOT DELETE THIS EMAIL WITH THE LOGIN CREDENTIALS</div><br/>
	<p><strong>Please note:</strong>The purchase of the e-application form or the subsequent submission of the same, does not guarantee admission to the school or an invitation for an interview.</p>
	<p>The selection process would be at the full discretion of the school and a formal feedback on the outcome of the application will be intimated accordingly to the registered email.</p><br/>
	<p>Kind regards</p>
	<p>STC - Admissions</p>
	<b>This is an automated email from the S. Thomas' College, Mount Lavinia, Admissions</b>
</div><?php /**PATH C:\Projects\laravel\resources\views/mail/register.blade.php ENDPATH**/ ?>