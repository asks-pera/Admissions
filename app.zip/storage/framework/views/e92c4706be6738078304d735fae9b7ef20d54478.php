

<?php $__env->startSection('header'); ?>
<script type='text/javascript'>
	function religionselected() {
		document.getElementById('divChristian').hidden = !(document.getElementById('religion').value == "Christian");
	}

	function genderSelected() {
		document.getElementById('divMedium').hidden = !(document.getElementById('gender').value == "Boy");
	}

	function gradeSelected() {
		var grade = document.getElementById('grade_sought').value;
		var medium = document.getElementById('medium');
		for(var i = medium.length; i >= 0 ; i--) {
			medium.remove(i);
		}
		if(grade == "International A/Level"){
			medium.append(new Option('English', 'English'));
			return;
		}
		medium.append(new Option('Select Medium', ''));
		medium.append(new Option('Sinhala', 'Sinhala'));
		medium.append(new Option('Tamil', 'Tamil'));
		switch (grade) {
			case "Lower 4 (Grade 6)" :
			case "Upper 4 (Grade 7)" :
			case "Form 5 (Grade 8)" :
			case "Lower 6 (Grade 9)" : 
				medium.append(new Option('Bi-Lingual (Sinhala with English)', 'Bi-Lingual (Sinhala with English)'));
				medium.append(new Option('Bi-Lingual (Tamil with English)', 'Bi-Lingual (Tamil with English)'));
				break;
			case "A/Levels (Science Stream)":
			case "A/Levels (Commerce and Arts Stream)" :
				medium.append(new Option('English', 'English'));
				break;
		}
	}

	function selectMedium(value) {
		document.getElementById('medium').value = value;
	}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
	<a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('application/status')); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('year'); ?>
	- <?php echo e($year); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(isset($child)): ?>
		<div id="student_picture"><img src="<?php echo e(url('/uploads/' . $child['picture'] . '')); ?>" height='120' alt="" style='float:right' /></div>
	<?php endif; ?>
	<h2>Child's Details</h2>
	<div class="row border border-dark rounded" style="margin:10px; padding:50px; display:block;">
		<form action="" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<input type="hidden" value="<?php echo e($id); ?>" name="id" />
			<input type="hidden" value="<?php echo e($section); ?>" name="section" />
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label for="surname" class="col-md-4 col-form-label">* Surname</label>
				<div class="col-md-8"><input type="text" class="form-control" maxlength="50" placeholder="Enter surname of child" id="surname" name="surname" value="<?php if(isset($child)): ?><?php echo e($child['surname']); ?><?php else: ?><?php echo e(old('surname')); ?><?php endif; ?>"/></div>
				<?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<small>Note: Surname as per birth certificate.</small>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label for="other_names" class="col-md-4 col-form-label">* Other names</label>
				<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Enter other names of the child" id="other_names" name="other_names" value="<?php if(isset($child)): ?><?php echo e($child['other_names']); ?><?php else: ?><?php echo e(old('other_names')); ?><?php endif; ?>" /></div>
				<?php $__errorArgs = ['other_names'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<small>Note: Other names as per birth certificate.</small>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="bc_num">* Birth Certificate Number</label>
				<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Birth Certificate Number" id="bc_num" name="bc_num" value="<?php if(isset($child)): ?><?php echo e($child['bc_num']); ?><?php else: ?><?php echo e(old('bc_num')); ?><?php endif; ?>" /></div>
				<?php $__errorArgs = ['bc_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<?php if($section == "Nursery"): ?>
				<div class = "form-group row" style="padding-bottom: 20px;">
					<label class="col-md-4 col-form-label" for="gender">* Gender</label>
					<div class="col-md-8"><select id="gender" name="gender" class="form-control" onchange="genderSelected()">
						<option value="">Select Gender</option>
						<option value="Boy" <?php if((isset($child)) && ($child['gender'] == 'Boy')): ?> selected <?php elseif(old('gender')=='Boy'): ?> selected <?php endif; ?>>Boy</option>
						<option value="Girl" <?php if((isset($child)) && ($child['gender'] == 'Girl')): ?> selected <?php elseif(old('gender')=='Girl'): ?> selected <?php endif; ?>>Girl</option>
					</select></div>
					<?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			<?php endif; ?>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="dob">* Date of Birth</label>
				<div class="col-md-8"><input class="form-control" type="date" name="dob" id="dob" value="<?php if(isset($child)): ?><?php echo e($child['dob']); ?><?php else: ?><?php echo e(old('dob')); ?><?php endif; ?>" /></div>
				<?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div><br/>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="present_school">* Name of present school (including pre-school)</label>
				<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Name of present school (including pre-school)" id="present_school" name="present_school" value="<?php if(isset($child)): ?><?php echo e($child['present_school']); ?><?php else: ?><?php echo e(old('present_school')); ?><?php endif; ?>" /></div>
				<?php $__errorArgs = ['present_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<?php if(($section != 'Nursery') && ($section != 'Kindergarten (Grade 1)')): ?>
				<div class = "form-group row" style="padding-bottom: 20px;">
					<label class="col-md-4 col-form-label" for="present_school_joined">Joining date of present school</label>
					<div class="col-md-8"><input class="form-control" type="date" placeholder="Joining date of the present school" id="present_school_joined" name="present_school_joined" value="<?php if(isset($child)): ?><?php echo e($child['present_school_joined']); ?><?php else: ?><?php echo e(old('present_school_joined')); ?><?php endif; ?>" /></div>
				</div>
				<?php $__errorArgs = ['present_school_joined'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<div class = "form-group row" style="padding-bottom: 20px;">
					<label class="col-md-4 col-form-label" for="previous_schools">Names of Previous schools (if any)</label>
					<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Names of Previous schools (if any)" id="previous_schools" name="previous_schools" value="<?php if(isset($child)): ?><?php echo e($child['previous_schools']); ?><?php else: ?><?php echo e(old('previous_schools')); ?><?php endif; ?>" /></div>
				</div>
				<?php $__errorArgs = ['previous_schools'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			<?php endif; ?>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="grade_sought">* Grade / Section to which admission is sought</label>
				<div class="col-md-8"><select class="form-control" id="grade_sought" name="grade_sought" onchange="gradeSelected()" />
					<option value="">Select Grade / Section</option>
					<?php if($section == "Nursery"): ?>
						<option value="Nursery 2+" <?php if(isset($child) && $child['grade_sought'] == 'Nursery 2+'): ?> selected <?php elseif(old('grade_sought')=='Nursery 2+'): ?> selected <?php endif; ?>>Nursery 2+</option>
						<option value="Nursery 3+" <?php if(isset($child) && $child['grade_sought'] == 'Nursery 3+'): ?> selected <?php elseif(old('grade_sought')=='Nursery 3+'): ?> selected <?php endif; ?>>Nursery 3+</option>
						<option value="Nursery 4+" <?php if(isset($child) && $child['grade_sought'] == 'Nursery 4+'): ?> selected <?php elseif(old('grade_sought')=='Nursery 4+'): ?> selected <?php endif; ?>>Nursery 4+</option>
					<?php elseif($section == "Kindergarten (Grade 1)"): ?>
						<option value="Kindergarten (Grade 1)" <?php if(isset($child) && $child['grade_sought'] == 'Kindergarten (Grade 1)'): ?> selected <?php elseif(old('grade_sought')=='Kindergarten (Grade 1)'): ?> selected <?php endif; ?>>Kindergarten (Grade 1)</option>
					<?php elseif($section == "Other Grades"): ?>
						<option value="Form 1 (Grade 2)" <?php if(isset($child) && $child['grade_sought'] == 'Form 1 (Grade 2)'): ?> selected <?php elseif(old('grade_sought')=='Form 1 (Grade 2)'): ?> selected <?php endif; ?>>Form 1 (Grade 2)</option>
						<option value="Form 2 (Grade 3)" <?php if(isset($child) && $child['grade_sought'] == 'Form 2 (Grade 3)'): ?> selected <?php elseif(old('grade_sought')=='Form 2 (Grade 3)'): ?> selected <?php endif; ?>>Form 2 (Grade 3)</option>
						<option value="Lower 3 (Grade 4)" <?php if(isset($child) && $child['grade_sought'] == 'Lower 3 (Grade 4)'): ?> selected <?php elseif(old('grade_sought')=='Lower 3 (Grade 4)'): ?> selected <?php endif; ?>>Lower 3 (Grade 4)</option>
						<option value="Upper 3 (Grade 5)" <?php if(isset($child) && $child['grade_sought'] == 'Upper 3 (Grade 5)'): ?> selected <?php elseif(old('grade_sought')=='Upper 3 (Grade 5)'): ?> selected <?php endif; ?>>Upper 3 (Grade 5)</option>
						<option value="Upper 4 (Grade 7)" <?php if(isset($child) && $child['grade_sought'] == 'Upper 4 (Grade 7)'): ?> selected <?php elseif(old('grade_sought')=='Upper 4 (Grade 7)'): ?> selected <?php endif; ?>>Upper 4 (Grade 7)</option>
						<option value="Form 5 (Grade 8)" <?php if(isset($child) && $child['grade_sought'] == 'Form 5 (Grade 8)'): ?> selected <?php elseif(old('grade_sought')=='Form 5 (Grade 8)'): ?> selected <?php endif; ?>>Form 5 (Grade 8)</option>
						<option value="Lower 6 (Grade 9)" <?php if(isset($child) && $child['grade_sought'] == 'Lower 6 (Grade 9)'): ?> selected <?php elseif(old('grade_sought')=='Lower 6 (Grade 9)'): ?> selected <?php endif; ?>>Lower 6 (Grade 9)</option>
					<?php elseif($section == 'Grade 6'): ?>
						<option value="Lower 4 (Grade 6)" <?php if(isset($child) && $child['grade_sought'] == 'Lower 4 (Grade 6)'): ?> selected <?php elseif(old('grade_sought')=='Lower 4 (Grade 6)'): ?> selected <?php endif; ?>>Lower 4 (Grade 6)</option>
					<?php else: ?>
						<option value="A/Levels (Science Stream)" <?php if(isset($child) && $child['grade_sought'] == 'A/Levels (Science Stream)'): ?> selected <?php elseif(old('grade_sought')=='A/Levels (Science Stream)'): ?> selected <?php endif; ?>>A/Levels (Science Stream)</option>
						<option value="A/Levels (Commerce and Arts Stream)" <?php if(isset($child) && $child['grade_sought'] == 'A/Levels (Commerce and Arts Stream)'): ?> selected <?php elseif(old('grade_sought')=='A/Levels (Commerce and Arts Stream)'): ?> selected <?php endif; ?>>A/Levels (Commerce and Arts Stream)</option>
						<option value="International A/Level" <?php if(isset($child) && $child['grade_sought'] == 'International A/Level'): ?> selected <?php elseif(old('grade_sought')=='International A/Level'): ?> selected <?php endif; ?>>International A/Level</option>
					<?php endif; ?>
				</select></div>
				<?php $__errorArgs = ['grade_sought'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<?php if($section == "Nursery"): ?> 
				<div class="form-group row" style="padding-bottom: 20px;" id="divMedium" <?php if(isset($child)): ?> <?php if($child['gender'] != 'Boy'): ?> hidden <?php endif; ?> <?php elseif(old('gender')!='Boy'): ?> hidden <?php endif; ?>>
					<label class="col-md-4 col-form-label" for="medium">* Medium at Kindergarten (Grade 1)</label>
					<div class="col-md-8"><select class="form-control" id="medium" name="medium">
						<option value="">Select Medium</option>
						<option value="Sinhala" <?php if(isset($child)): ?> <?php if($child['medium'] == 'Sinhala'): ?> selected <?php endif; ?> <?php elseif(old('medium')=='Sinhala'): ?> selected <?php endif; ?>>Sinhala</option>
						<option value="Tamil" <?php if(isset($child)): ?> <?php if($child['medium'] == 'Tamil'): ?> selected <?php endif; ?> <?php elseif(old('medium')=='Tamil'): ?> selected <?php endif; ?>>Tamil</option>
					</select></div>
					<?php $__errorArgs = ['medium'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			<?php else: ?>
				<div class = "form-group row" style="padding-bottom: 20px;" id="divmedium">
					<label class="col-md-4 col-form-label" for="medium">* Medium</label>
					<div class="col-md-8"><select class="form-control" id="medium" name="medium"/>
						<option value="">Select Medium</option>
					</select></div>
					<?php $__errorArgs = ['medium'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			<?php endif; ?>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="religion">* Religion</label>
				<div class="col-md-8"><select id="religion" name="religion" class="form-control" onchange="religionselected()">
					<option value="">Select Religion</option>
					<option value="Christian" <?php if((isset($child)) && ($child['religion'] == 'Christian')): ?> selected <?php elseif(old('religion')=='Christian'): ?> selected <?php endif; ?>>Christian</option>
					<option value="Buddhist" <?php if((isset($child)) && ($child['religion'] == 'Buddhist')): ?> selected <?php elseif(old('religion')=='Buddhist'): ?> selected <?php endif; ?>>Buddhist</option>
					<option value="Islam" <?php if((isset($child)) && ($child['religion'] == 'Islam')): ?> selected <?php elseif(old('religion')=='Islam'): ?> selected <?php endif; ?>>Islam</option>
					<option value="Hinduism" <?php if((isset($child)) && ($child['religion'] == 'Hinduism')): ?> selected <?php elseif(old('religion')=='Hinduism'): ?> selected <?php endif; ?>>Hinduism</option>
				</select></div>
				<?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div id="divChristian" <?php if(isset($child)): ?> <?php if($child['religion'] != 'Christian'): ?> hidden <?php endif; ?> <?php elseif(old('religion')!='Christian'): ?> hidden <?php endif; ?>>
				<div class = "form-group row" style="padding-bottom: 20px;">
					<label class="col-md-4 col-form-label" for="denomination">* Denomination</label>
					<div class="col-md-8"><input class="form-control" type="text" maxlength="50" placeholder="Denomination" id="denomination" name="denomination" value="<?php if(isset($child)): ?><?php echo e($child['denomination']); ?><?php else: ?><?php echo e(old('denomination')); ?><?php endif; ?>" /></div>
					<?php $__errorArgs = ['denomination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class = "form-group row" style="padding-bottom: 20px;">
					<label class="col-md-4 col-form-label" for="baptism_date">* Date of baptism of child</label>
					<div class="col-md-8"><input class="form-control" type="date" id="baptism_date" name="baptism_date" value="<?php if(isset($child)): ?><?php echo e($child['baptism_date']); ?><?php else: ?><?php echo e(old('baptism_date')); ?><?php endif; ?>"/></div>
					<?php $__errorArgs = ['baptism_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="picture">* Upload recent photograph<br/><small>Max file size = 1Mb</small></label>
				<div class="col-md-8"><input class="form-control" type="file" name="picture" id="picture" accept="image/*" /></div>
				<input type="hidden" name="file" value="<?php if(isset($child)): ?><?php echo e($child['picture']); ?><?php else: ?><?php echo e(old('picture')); ?><?php endif; ?>" />
				<?php $__errorArgs = ['picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="row">
				<div class="col-md-6 text-center"><a class="btn btn-primary btn-lg" style="margin:10px 0;" type="button" href="<?php echo e(url('application/status')); ?>">Back</a></div>
				<div class="col-md-6 text-center"><input class="btn btn-primary btn-lg" style="margin:10px 0;" type="submit" <?php if(!isset($child)): ?> value="Save Data" <?php else: ?> value="Update Data" <?php endif; ?> id="cmdSave" name="cmdSave"/></div>
			</div>
		</form>
	</div>
	<script>
		gradeSelected();
	</script>
	<?php if(isset($child)): ?>
		<script>
			selectMedium("<?php echo e($child['medium']); ?>");
		</script>
	<?php elseif(old('medium')): ?>
		<script>
			selectMedium("<?php echo e(old('medium')); ?>");
		</script>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/application/child.blade.php ENDPATH**/ ?>