<div>
	<div style="text-align: center;"><img src="https://admissions.stcmount.com/images/crest2.png" alt="Missing Crest" height="100px" /></div>
	<h1>S. Thomas' College, Mount, Lavinia - Admissions</h1>
	<h2>Email Verification</h2><br/><br/>
	<p>Please click the following link to verify the email address in order to purchase an application form for admissions.</p><br/>
	<?php $__env->startComponent('mail::button', ['url' => 'https://admissions.stcmount.com/register?section=<?php echo e($section); ?>&email=<?php echo e($email); ?>']); ?>
	<div style="padding-left:20px"><a href="https://admissions.stcmount.com/register?section=<?php echo e($section); ?>&email=<?php echo e($email); ?>">Verify email address</a></div><br/><br/>
	<p>Kind regards</p>
	<p>STC - Admissions</p>
	<b>This is an automated email from the S. Thomas' College, Mount Lavinia, Admissions</b>
</div>
<?php /**PATH C:\Projects\laravel\resources\views/mail/verifyemail.blade.php ENDPATH**/ ?>