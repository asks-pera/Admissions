

<?php $__env->startSection('content'); ?>
	<h2>For Office Use Only</h2>
	<div class="mask d-flex align-items-center h-100">
        <div class="container">
          	<div class="row justify-content-center">
            	<div class="col-xl-5 col-md-8">
              		<form class="bg-white  rounded-5 shadow-5-strong p-5" action="" method="post">
              			<?php echo csrf_field(); ?>
                		<div class="form-outline mb-4">
                  			<input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>"/>
                  			<label class="form-label" for="name">Username</label>
                  			<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div style="color:red"><?php echo e($message); ?></div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                		</div>
		                <div class="form-outline mb-4">
		                  	<input type="password" id="password" name="password" class="form-control" />
		                  	<label class="form-label" for="password">Password</label>
		                  	<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div style="color:red"><?php echo e($message); ?></div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		                </div>
                		<button type="submit" class="btn btn-primary btn-block">Login</button>
              		</form>
            	</div>
          	</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\laravel\resources\views/admin/login.blade.php ENDPATH**/ ?>