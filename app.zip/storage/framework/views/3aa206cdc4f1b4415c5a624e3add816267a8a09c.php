

<?php $__env->startSection('navigation'); ?>
	<a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(URL::previous()); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	ID = <?php echo e($id); ?>

	<div style="height: 5em; position: relative">
		<div style="margin: 0; position: absolute; top: 50%; left: 50%; margin-right: -50%; transform: translate(-50%, -50%)">
			<table border="2" style="text-align: center;">
				<thead>
					<th>Purchased</th>
					<th>Child</th>
					<th>Father</th>
					<th>Mother</th>
					<th>Other Children</th>
					<?php if(($section=='ALevels') || ($section=='Branch Schools') || ($section=='Grade 6')): ?>
						<th>Results</th>
					<?php endif; ?>
						<th>Church</th>
					<?php if(($section == 'ALevels') || ($section == 'Branch Schools')): ?>
						<th>Subjects</th>
					<?php endif; ?>
						<th>OBA</th>
					<th>Staff</th>
					<th>Connections</th>
					<?php if($section != 'Nursery'): ?>
						<th>General</th>
					<?php endif; ?>
					<th>Submitted</th>
				</thead>
				<tr>
					<td><?php echo e($status['purchased']); ?></td>
					<td><?php echo e($status['child']); ?></td>
					<td><?php echo e($status['father']); ?></td>
					<td><?php echo e($status['mother']); ?></td>
					<td><?php echo e($status['other']); ?></td>
					<?php if(($section=='ALevels') || ($section=='Branch Schools') || ($section=='Grade 6')): ?>
						<td><?php echo e($status['results']); ?></td>
					<?php endif; ?>
					<td><?php echo e($status['church']); ?></td>
					<?php if(($section == 'ALevels') || ($section == 'Branch Schools')): ?>
						<td><?php echo e($status['subjects']); ?></td>
					<?php endif; ?>
					<td><?php echo e($status['oba']); ?></td>
					<td><?php echo e($status['staff']); ?></td>
					<td><?php echo e($status['connections']); ?></td>
					<?php if($section != 'Nursery'): ?>
						<td><?php echo e($status['general']); ?></td>
					<?php endif; ?>
					<td><?php echo e($status['submitted']); ?></td>
				</tr>
			</table>
		</div>
	</div>

	<div style="float:right; padding-right:10px; margin-top:15px"><img src="<?php echo e(url('images/' . $child['picture'])); ?>" height="150px" alt="Child's Picture"></div>
	<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">Child Information</p>
	<table style="border:solid black 0px; padding-left:30px;">
		<tr><td style="width: 150px;">Surname :</td><td style="width: 540px;"><?php echo e($child['surname']); ?></td></tr>
		<tr><td>Other Names :</td><td><?php echo e($child['other_names']); ?></td></tr>
		<?php if($section == 'Nursery'): ?>
			<tr><td>Gender :</td><td><?php echo e($child['gender']); ?></td></tr>
		<?php endif; ?>
		<tr><td>Date of Birth :</td><td><?php echo e($child['dob']); ?></td></tr>
		<tr><td>BC Number :</td><td><?php echo e($child['bc_num']); ?></td></tr>
		<tr><td>Present School :</td><td><?php echo e($child['present_school']); ?></td></tr>
		<?php if($child['present_school_joined'] !== null): ?>
			<tr><td>Joined Date :</td><td><?php echo e($child['present_school_joined']); ?></td></tr>
		<?php endif; ?>
		<?php if($child['previous_schools'] !== null): ?>
			<tr><td>Previous Schools :</td><td><?php echo e($child['previous_schools']); ?></td></tr>
		<?php endif; ?>
		<?php if($child['grade_sought'] !== null): ?> 
	        <tr><td>Section / Grade : </td><td><?php echo e($child['grade_sought']); ?></td></tr>
	    <?php endif; ?>
		<?php if($child['medium'] !== null): ?>
			<tr><td>Medium :</td><td><?php echo e($child['medium']); ?></td></tr>
		<?php endif; ?>
		<tr><td>Religion :</td><td><?php echo e($child['religion']); ?></td></tr>
		<?php if($child['religion'] == "Christian"): ?>
			<tr><td>Denomination :</td><td><?php echo e($child['denomination']); ?></td></tr>
			<tr><td>Baptism Date :</td><td><?php echo e($child['baptism_date']); ?></td></tr>
		<?php endif; ?>
	</table>
	<table style="margin-top:30px; border:solid black 0px; padding-left:30px;">
		<tr><td style="width: 150px;"></td><td style="width:215px; padding-left:20px; font-size: 18px; font-weight:bold;">Father</td><td style="width:245px; padding-left:20px; font-size: 18px; font-weight:bold;">Mother</td></tr>
		<tr><td>Name :</td><td><?php echo e($father['name']); ?></td><td><?php echo e($mother['name']); ?></td></tr>
		<tr><td>Occupation :</td><td><?php echo e($father['occupation']); ?></td><td><?php echo e($mother['occupation']); ?></td></tr>
		<tr><td>Employment :</td><td><?php echo e($father['employment']); ?></td><td><?php echo e($mother['employment']); ?></td></tr>
		<tr><td>Mobile :</td><td><?php echo e($father['mobile']); ?></td><td><?php echo e($mother['mobile']); ?></td></tr>
		<tr><td>Email :</td><td><?php echo e($father['email']); ?></td><td><?php echo e($mother['email']); ?></td></tr>
		<tr><td>Address :</td><td><?php echo e($father['address']); ?></td><td><?php echo e($mother['address']); ?></td></tr>
		<tr><td>NIC :</td><td><?php echo e($father['nic']); ?></td><td><?php echo e($mother['nic']); ?></td></tr>
		<?php if(($father['religion']!="Other") && ($mother['religion']!="Other")): ?>
		    <tr><td>Religion :</td><td><?php echo e($father['religion']); ?></td><td><?php echo e($mother['religion']); ?></td></tr>
		<?php elseif(($father['religion']=="Other") && ($mother['religion']!="Other")): ?>
		    <tr><td>Religion :</td><td><?php echo e($father['other']); ?></td><td><?php echo e($mother['religion']); ?></td></tr>
		<?php elseif(($father['religion']!="Other") && ($mother['religion']=="Other")): ?>
		    <tr><td>Religion :</td><td><?php echo e($father['religion']); ?></td><td><?php echo e($mother['other']); ?></td></tr>
        <?php elseif(($father['religion']=="Other") && ($mother['religion']=="Other")): ?>
		    <tr><td>Religion :</td><td><?php echo e($father['other']); ?></td><td><?php echo e($mother['other']); ?></td></tr>
		<?php endif; ?>
		<?php if(($father['religion']=="Christian") && ($mother['religion']=="Christian")): ?>
		    <tr><td>Denomination :</td><td><?php echo e($father['denomination']); ?></td><td><?php echo e($mother['denomination']); ?></td></tr>
		    <tr><td>Baptism Date :</td><td><?php echo e($father['baptism_date']); ?></td><td><?php echo e($mother['baptism_date']); ?></td></tr>
		<?php elseif(($father['religion']!="Christian") && ($mother['religion']=="Christian")): ?>
		    <tr><td>Denomination :</td><td></td><td><?php echo e($mother['denomination']); ?></td></tr>
		    <tr><td>Baptism Date :</td><td></td><td><?php echo e($mother['baptism_date']); ?></td></tr>
		<?php elseif(($father['religion']=="Christian") && ($mother['religion']!="Christian")): ?>
		    <tr><td>Denomination :</td><td><?php echo e($father['denomination']); ?></td><td></td></tr>
		    <tr><td>Baptism Date :</td><td><?php echo e($father['baptism_date']); ?></td><td></td></tr>
		<?php endif; ?>
		<?php if($father['old_thomian']): ?>
			<tr><td>Old School :</td><td>S. Thomas' College</td><td><?php echo e($mother['old_school']); ?></td></tr>
		<?php else: ?>
			<tr><td>Old School :</td><td><?php echo e($father['old_school']); ?></td><td><?php echo e($mother['old_school']); ?></td></tr>
		<?php endif; ?>
	</table>
	<?php if($child['religion'] == "Christian"): ?>
		<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">Church Details</p>
		<table style="border:solid black 0px; padding-left:30px;">
			<tr><td style="width: 150px;">Parish :</td><td style="width: 540px;"><?php echo e($church['parish']); ?></td></tr>
			<tr><td>Parish Priest :</td><td><?php echo e($church['priest']); ?></td></tr>
		</table>
	<?php endif; ?>
	<?php if($other['num'] > 0): ?>
		<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">Other Children : <?php echo e($other['num']); ?></p>
		<table style="margin-top:5px; border:solid black 0px; padding-left:30px;">
			<tr><td style="width: 100px;">Name :</td><td style="width: 190px;"><?php echo e($other['name_1']); ?></td><td style="width: 100px;">Name :</td><td style="width: 190px;"><?php echo e($other['name_2']); ?></td></tr>
			<tr><td>Gender :</td><td><?php echo e($other['sex_1']); ?></td><td>Gender :</td><td><?php echo e($other['sex_2']); ?></td></tr>
			<tr><td>DoB :</td><td><?php echo e($other['dob_1']); ?></td><td>DoB :</td><td><?php echo e($other['dob_2']); ?></td></tr>
			<tr><td>School :</td><td><?php echo e(($other['stc_1']) ? 'STC' : $other['school_1']); ?></td><td>School :</td><td><?php echo e(($other['stc_2']) ? 'STC' : $other['school_2']); ?></td></tr>
			<?php if($other['stc_1'] && $other['stc_2']): ?>
				<tr><td>Class :</td><td><?php echo e($other['class_1']); ?></td><td>Class :</td><td><?php echo e($other['class_2']); ?></td></tr>
				<tr><td>House :</td><td><?php echo e($other['house_1']); ?></td><td>House :</td><td><?php echo e($other['house_2']); ?></td></tr>
				<tr><td>Admission :</td><td><?php echo e($other['admission_1']); ?></td><td>Admission :</td><td><?php echo e($other['admission_2']); ?></td></tr>
				<tr><td>Medium :</td><td><?php echo e($other['medium_1']); ?></td><td>Medium :</td><td><?php echo e($other['medium_2']); ?></td></tr>
			<?php elseif($other['stc_1'] && !$other['stc_2']): ?>
				<tr><td>Class :</td><td><?php echo e($other['class_1']); ?></td><td></td><td></td></tr>
				<tr><td>House :</td><td><?php echo e($other['house_1']); ?></td><td></td><td></td></tr>
				<tr><td>Admission :</td><td><?php echo e($other['admission_1']); ?></td><td></td><td></td></tr>
				<tr><td>Medium :</td><td><?php echo e($other['medium_1']); ?></td><td></td><td></td></tr>
			<?php elseif(!$other['stc_1'] && $other['stc_2']): ?>
				<tr><td></td><td></td><td>Class :</td><td><?php echo e($other['class_2']); ?></td></tr>
				<tr><td></td><td></td><td>House :</td><td><?php echo e($other['house_2']); ?></td></tr>
				<tr><td></td><td></td><td>Admission :</td><td><?php echo e($other['admission_2']); ?></td></tr>
				<tr><td></td><td></td><td>Medium :</td><td><?php echo e($other['medium_2']); ?></td></tr>
			<?php endif; ?>
		</table>
		<?php if($other['num'] > 2): ?>
			<table style="margin-top:30px; border:solid black 0px; padding-left:30px;">
				<tr><td style="width: 100px;">Name :</td><td style="width: 190px;"><?php echo e($other['name_3']); ?></td><td style="width: 100px;">Name :</td><td style="width: 190px;"><?php echo e($other['name_4']); ?></td></tr>
				<tr><td>Gender :</td><td><?php echo e($other['sex_3']); ?></td><td>Gender :</td><td><?php echo e($other['sex_4']); ?></td></tr>
				<tr><td>DoB :</td><td><?php echo e($other['dob_3']); ?></td><td>DoB :</td><td><?php echo e($other['dob_4']); ?></td></tr>
				<tr><td>School :</td><td><?php echo e(($other['stc_3']) ? 'STC' : $other['school_3']); ?></td><td>School :</td><td><?php echo e(($other['stc_4']) ? 'STC' : $other['school_4']); ?></td></tr>
				<?php if($other['stc_3'] && $other['stc_4']): ?>
					<tr><td>Class :</td><td><?php echo e($other['class_3']); ?></td><td>Class :</td><td><?php echo e($other['class_4']); ?></td></tr>
					<tr><td>House :</td><td><?php echo e($other['house_3']); ?></td><td>House :</td><td><?php echo e($other['house_4']); ?></td></tr>
					<tr><td>Admission :</td><td><?php echo e($other['admission_3']); ?></td><td>Admission :</td><td><?php echo e($other['admission_4']); ?></td></tr>
					<tr><td>Medium :</td><td><?php echo e($other['medium_3']); ?></td><td>Medium :</td><td><?php echo e($other['medium_4']); ?></td></tr>
				<?php elseif($other['stc_3'] && !$other['stc_4']): ?>
					<tr><td>Class :</td><td><?php echo e($other['class_3']); ?></td><td></td><td></td></tr>
					<tr><td>House :</td><td><?php echo e($other['house_3']); ?></td><td></td><td></td></tr>
					<tr><td>Admission :</td><td><?php echo e($other['admission_3']); ?></td><td></td><td></td></tr>
					<tr><td>Medium :</td><td><?php echo e($other['medium_3']); ?></td><td></td><td></td></tr>
				<?php elseif(!$other['stc_3'] && $other['stc_4']): ?>
					<tr><td></td><td></td><td>Class :</td><td><?php echo e($other['class_4']); ?></td></tr>
					<tr><td></td><td></td><td>House :</td><td><?php echo e($other['house_4']); ?></td></tr>
					<tr><td></td><td></td><td>Admission :</td><td><?php echo e($other['admission_4']); ?></td></tr>
					<tr><td></td><td></td><td>Medium :</td><td><?php echo e($other['medium_4']); ?></td></tr>
				<?php endif; ?>
			</table>
		<?php endif; ?>
		<br/>
	<?php endif; ?>
	<?php if($father['old_thomian']): ?>
		<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">OBA Details</p>
		<table style="margin-top:5px; border:solid black 0px; padding-left:30px;">
			<?php if($oba['mount']): ?>
				<tr><td style="width: 150px;">Mount Lavinia :</td><td style="width: 190px;">YES</td><td style="width: 150px;"></td><td style="width: 190px;"></td></tr>
				<tr><td>From : </td><td><?php echo e($oba['mount_from']); ?></td><td>To : </td><td><?php echo e($oba['mount_to']); ?></td></tr>
				<tr><td>House : </td><td><?php echo e($oba['house']); ?></td><td>Admission No. : </td><td><?php echo e($oba['admission']); ?></td></tr>
				<br/>
			<?php endif; ?>
			<?php if($oba['guru']): ?>
				<tr><td>Gurutalawa :</td><td>YES</td><td></td><td></td></tr>
				<tr><td>From : </td><td><?php echo e($oba['guru_from']); ?></td><td>To : </td><td><?php echo e($oba['guru_to']); ?></td></tr>
				<br/>
			<?php endif; ?>
			<?php if($oba['banda']): ?>
				<tr><td>Bandarawela :</td><td>YES</td><td></td><td></td></tr>
				<tr><td>From : </td><td><?php echo e($oba['banda_from']); ?></td><td>To : </td><td><?php echo e($oba['banda_to']); ?></td></tr>
				<br/>
			<?php endif; ?>
			<?php if($oba['prep']): ?>
				<tr><td>Kollupitiya :</td><td>YES</td><td></td><td></td></tr>
				<tr><td>From : </td><td><?php echo e($oba['prep_from']); ?></td><td>To : </td><td><?php echo e($oba['prep_to']); ?></td></tr>
				<br/>
			<?php endif; ?>
			<?php if($oba['oba_member']): ?>
				<tr><td>OBA Member :</td><td>YES</td><td></td><td></td></tr>
				<tr><td>OBA Number : </td><td><?php echo e($oba['oba_number']); ?></td><td>Joining Date : </td><td><?php echo e($oba['oba_date']); ?></td></tr>
				<tr><td>From : </td><td><?php echo e($oba['prep_from']); ?></td><td>To : </td><td><?php echo e($oba['prep_to']); ?></td></tr>
			<?php else: ?>
				<tr><td>OBA Member :</td><td>NO</td><td></td><td></td></tr>
			<?php endif; ?>
		</table><br/>
	<?php endif; ?>
	<?php if($staff['mother_staff']): ?>
		<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">Mother is a member of staff</p>
		<table style="border:solid black 0px; padding-left:30px;">
			<tr><td style="width: 150px;">Name :</td><td style="width: 540px;"><?php echo e($staff['mother_name']); ?></td></tr>
			<tr><td>Joined Date :</td><td><?php echo e($staff['mother_joined']); ?></td></tr>
			<tr><td>Section :</td><td><?php echo e($staff['mother_section']); ?></td></tr>
			<tr><td>EPF :</td><td><?php echo e($staff['mother_EPF']); ?></td></tr>
		</table><br/>
	<?php endif; ?>
	<?php if($staff['father_staff']): ?>
		<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">Father is a member of staff</p>
		<table style="border:solid black 0px; padding-left:30px;">
			<tr><td style="width: 150px;">Name :</td><td style="width: 540px;"><?php echo e($staff['father_name']); ?></td></tr>
			<tr><td>Joined Date :</td><td><?php echo e($staff['father_joined']); ?></td></tr>
			<tr><td>Section :</td><td><?php echo e($staff['father_section']); ?></td></tr>
			<tr><td>EPF :</td><td><?php echo e($staff['father_EPF']); ?></td></tr>
		</table><br/>
	<?php endif; ?>
	<?php if(($section == "Branch Schools") || ($section == "ALevels") || ($section == "Grade 6")): ?>
		<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">Examination Results</p>
		<table style="border:solid black 0px; padding-left:30px;">
		<?php if($section == "Grade 6"): ?>
			<tr><td style="width: 150px;">Schol Index :</td><td style="width: 540px;"><?php echo e($results['scholindex']); ?></td></tr>
			<tr><td>Schol Marks :</td><td><?php echo e($results['scholmark']); ?></td></tr>
		<?php else: ?>
			<?php if($section == "ALevels"): ?>
				<tr><td style="width: 150px;">O/Level Index :</td><td style="width: 540px;"><?php echo e($results['olindex']); ?></td></tr>
			<?php endif; ?>
			<tr><td style="width: 250px;">Religion :</td><td style="width: 340px;"><?php echo e($results['olreligion']); ?></td></tr>
			<tr><td>First Language : </td><td><?php echo e($results['olfirstlang']); ?></td></tr>
			<tr><td>English : </td><td><?php echo e($results['olenglish']); ?></td></tr>
			<tr><td>Science : </td><td><?php echo e($results['olscience']); ?></td></tr>
			<tr><td>Math : </td><td><?php echo e($results['olmath']); ?></td></tr>
			<tr><td>History : </td><td><?php echo e($results['olhistory']); ?></td></tr>
			<tr><td><?php echo e($results['olbasket1subject']); ?> : </td><td><?php echo e($results['olbasket1result']); ?></td></tr>
			<tr><td><?php echo e($results['olbasket2subject']); ?> : </td><td><?php echo e($results['olbasket2result']); ?></td></tr>
			<tr><td><?php echo e($results['olbasket3subject']); ?> : </td><td><?php echo e($results['olbasket3result']); ?></td></tr>
		<?php endif; ?>
		</table><br/>
	<?php endif; ?>
	<?php if(($section == "Branch Schools") || ($section == "ALevels")): ?>
		<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">A/Level Subject Choices</p>
		<table style="border:solid black 0px; padding-left:30px;">
			<tr><td style="width: 150px;">Subject 1 :</td><td style="width: 540px;"><?php echo e($subjects['alsubject1']); ?></td></tr>
			<tr><td>Subject 2 :</td><td><?php echo e($subjects['alsubject2']); ?></td></tr>
			<tr><td>Subject 3 :</td><td><?php echo e($subjects['alsubject3']); ?></td></tr>
			<tr><td>Subject 4 :</td><td><?php echo e($subjects['alsubject4']); ?></td></tr>
		</table><br/>
	<?php endif; ?>
	<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">Thomian Connections</p>
	<table style="border:solid black 0px; padding-left:30px;">
		<tr><td style="width: 150px;">Connections :</td><td style="width: 540px;"><?php echo e($connections['connection']); ?></td></tr>
	</table><br/>
	<?php if($section != 'Nursery'): ?>
		<p style="padding-left:20px; font-size: 18px; font-weight:bold; margin:28px 0px 5px 0px">General</p>
		<table style="border:solid black 0px; padding-left:30px;">
			<tr><td style="width: 150px;">Boarding / Day Boarding :</td><td style="width: 540px;"><?php echo e($general['boarding']); ?></td></tr>
			<?php if($section != 'Kindergarten (Grade 1)'): ?>
				<tr><td style="width: 150px;">Sports & Games :</td><td style="width: 540px;"><?php echo e($general['sports']); ?></td></tr>
				<tr><td>Clubs & Societies :</td><td><?php echo e($general['societies']); ?></td></tr>
				<tr><td>Other Achievements :</td><td><?php echo e($general['other']); ?></td></tr>
			<?php endif; ?>		
		</table><br/>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/admin/show.blade.php ENDPATH**/ ?>