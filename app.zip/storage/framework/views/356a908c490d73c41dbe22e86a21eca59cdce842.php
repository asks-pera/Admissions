<div>
	<div style="text-align:center"><img src="https://admissions.stcmount.com/images/crest2.jpg" height="60px" /></div>
	<h1>S. Thomas' College, Mount, Lavinia - Admissions <?php echo e($year); ?></h1>
	<h2>Email Verification</h2><br/><br/>
	<p>Thank you for interest in filling an application for admission for <?php echo e($section); ?> for <?php echo e($year); ?>.</p>
	<p>Please click the following link to verify the email address in order to purchase an application form for admissions.</p><br/>
	<?php $__env->startComponent('mail::button', ['url' => $link]); ?>
		Verify Email Address
	<?php echo $__env->renderComponent(); ?>
	<br/>
	<p>Kind regards</p>
	<p>Admissions</p>
	<p>S. Thomas' College, Mount Lavinia</p>
	<b>This is an automated email from the S. Thomas' College, Mount Lavinia, Admissions</b>
</div>
<?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/mail/verifyemail.blade.php ENDPATH**/ ?>