

<?php $__env->startSection('navigation'); ?>
	<a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('application/status')); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('year'); ?>
	- <?php echo e($year); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div id="student_picture"><img src="<?php echo e(url('/uploads/' . $picture . '')); ?>" height='120' alt="" style='float:right' /></div>
	<h2>Thomian Connections</h2>
	<form action="" method="post" border="1px border grey">
		<?php echo csrf_field(); ?>
		<input type="hidden" value="<?php echo e($id); ?>" name="id" />
		<div class = "form-group row" style="padding-bottom: 20px;">
			<p>What we consider Thomian Connections are - 
       		<ol>
       			<li>Maternal Father/ Grand Father being a Thomian</li>
       			<li>Paternal Father/ Grand Father being a Thomian</li>
       			<li>Maternal Uncle being a Thomian</li>
       			<li>Any aunt, uncle and grandparents being/been in the STC staff/ Board of Governors, etc. </li>
       		</ol>
       		<p>Please enter the details in the following format :-</p>
       		<p>Name of Old boy / staff member - Admission Number (if applicable) / duration of study / stay at STC Mount - Relationship to the child </p>
			<label class="col-md-4 col-form-label" for="connection">* Connections</label>
			<div class="col-md-8"><textarea class="form-control" style="height:75px" maxlength="500" placeholder="Enter details of Thomian connections" id="connection" name="connection"><?php if(isset($connections)): ?><?php echo e($connections['connection']); ?><?php else: ?><?php echo e(old('connection')); ?><?php endif; ?></textarea></div>
			<?php $__errorArgs = ['connection'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="col-md-4"></div>
				<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div class="row" style="margin-top:10px; ">
			<div class="col-md-6 text-center"><a class="btn btn-primary btn-lg" style="margin:10px 0;" type="button" href="<?php echo e(url('application/status')); ?>">Back</a></div>
			<div class="col-md-6 text-center"><input class="btn btn-primary btn-lg" style="margin:10px 0;" type="submit" <?php if(!isset($connections)): ?> value="Save Data" <?php else: ?> value="Update Data" <?php endif; ?> id="cmdSave" name="cmdSave"/></div>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/application/connections.blade.php ENDPATH**/ ?>