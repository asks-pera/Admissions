

<?php $__env->startSection('header'); ?>
<script type='text/javascript'>
	function religionselected() {
		document.getElementById('divChristian').hidden = !(document.getElementById('religion').value == "Christian");
		document.getElementById('divOther').hidden = !(document.getElementById('religion').value == "Other");
	}
	function oldboyClick() {
		document.getElementById('non_thomian').hidden = (document.getElementById('old_thomian').checked == true);
	}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
	<a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('application/status')); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('year'); ?>
	- <?php echo e($year); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div id="student_picture"><img src="<?php echo e(url('/uploads/' . $picture . '')); ?>" height='120' alt="" style='float:right' /></div>
	<h2>Father's Details</h2>
	<div class="row border border-dark rounded" style="margin:10px; padding:50px; display:block;">
		<form action="" method="post">
			<?php echo csrf_field(); ?>
			<input type="hidden" value="<?php echo e($id); ?>" name="id" />
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label for="name" class="col-md-4 col-form-label">* Name</label>
				<div class="col-md-8"><input type="text" class="form-control" maxlength="50" placeholder="Enter Name of Father" id="name" name="name" value="<?php if(isset($father)): ?><?php echo e($father['name']); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>"/></div>
				<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label for="occupation" class="col-md-4 col-form-label">* Occupation</label>
				<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Enter Occupation of the Father" id="occupation" name="occupation" value="<?php if(isset($father)): ?><?php echo e($father['occupation']); ?><?php else: ?><?php echo e(old('occupation')); ?><?php endif; ?>" /></div>
				<?php $__errorArgs = ['occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label for="employment" class="col-md-4 col-form-label">* Employment</label>
				<div class="col-md-8"><textarea class="form-control" style="height:75px" maxlength="500" placeholder="Enter Employment details of the Father" id="employment" name="employment"><?php if(isset($father)): ?><?php echo e($father['employment']); ?><?php else: ?><?php echo e(old('employment')); ?><?php endif; ?></textarea></div>
				<?php $__errorArgs = ['employment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label for="mobile" class="col-md-4 col-form-label">* Mobile</label>
				<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Enter Mobile number of the Father" id="mobile" name="mobile" value="<?php if(isset($father)): ?><?php echo e($father['mobile']); ?><?php else: ?><?php echo e(old('mobile')); ?><?php endif; ?>" /></div>
				<?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label for="email" class="col-md-4 col-form-label">* Email</label>
				<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Enter Email address of the Father" id="email" name="email" value="<?php if(isset($father)): ?><?php echo e($father['email']); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>" /></div>
				<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label for="address" class="col-md-4 col-form-label">* Residential Address</label>
				<div class="col-md-8"><textarea class="form-control" style="height:75px" maxlength="500" placeholder="Enter residential address" id="address" name="address"><?php if(isset($father)): ?><?php echo e($father['address']); ?><?php else: ?><?php echo e(old('address')); ?><?php endif; ?></textarea></div>
				<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="religion">* Religion</label>
				<div class="col-md-8"><select id="religion" name="religion" class="form-control" onchange="religionselected()">
					<option value="">Select Religion</option>
					<option value="Christian" <?php if((isset($father)) && ($father['religion'] == 'Christian')): ?> selected <?php elseif(old('religion')=='Christian'): ?> selected <?php endif; ?>>Christian</option>
					<option value="Buddhist" <?php if((isset($father)) && ($father['religion'] == 'Buddhist')): ?> selected <?php elseif(old('religion')=='Buddhist'): ?> selected <?php endif; ?>>Buddhist</option>
					<option value="Islam" <?php if((isset($father)) && ($father['religion'] == 'Islam')): ?> selected <?php elseif(old('religion')=='Islam'): ?> selected <?php endif; ?>>Islam</option>
					<option value="Hinduism" <?php if((isset($father)) && ($father['religion'] == 'Hinduism')): ?> selected <?php elseif(old('religion')=='Hinduism'): ?> selected <?php endif; ?>>Hinduism</option>
					<option value="Other" <?php if((isset($father)) && ($father['religion'] == 'Other')): ?> selected <?php elseif(old('religion')=='Other'): ?> selected <?php endif; ?>>Other</option>
				</select></div>
				<?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div id="divChristian" <?php if(isset($father)): ?> <?php if($father['religion'] != 'Christian'): ?> hidden <?php endif; ?> <?php elseif(old('religion')!='Christian'): ?> hidden <?php endif; ?>>
				<div class = "form-group row" style="padding-bottom: 20px;">
					<label class="col-md-4 col-form-label" for="denomination">* Denomination</label>
					<div class="col-md-8"><input class="form-control" type="text" maxlength="50" placeholder="Denomination" id="denomination" name="denomination" value="<?php if(isset($father)): ?><?php echo e($father['denomination']); ?><?php else: ?><?php echo e(old('denomination')); ?><?php endif; ?>" /></div>
					<?php $__errorArgs = ['denomination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="col-md-4"></div>
						<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class = "form-group row" style="padding-bottom: 20px;">
					<label class="col-md-4 col-form-label" for="baptism_date">* Date of baptism</label>
					<div class="col-md-8"><input class="form-control" type="date" id="baptism_date" name="baptism_date" value="<?php if(isset($father)): ?><?php echo e($father['baptism_date']); ?><?php else: ?><?php echo e(old('baptism_date')); ?><?php endif; ?>"/></div>
					<?php $__errorArgs = ['baptism_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="col-md-4"></div>
						<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div id="divOther" <?php if(isset($father)): ?> <?php if($father['religion'] != 'Other'): ?> hidden <?php endif; ?> <?php elseif(old('religion')!='Other'): ?> hidden <?php endif; ?>>
				<div class = "form-group row" style="padding-bottom: 20px;">
					<label class="col-md-4 col-form-label" for="other">* Other (Specify)</label>
					<div class="col-md-8"><input class="form-control" type="text" maxlength="50" placeholder="Religion Other" id="other" name="other" value="<?php if(isset($father)): ?><?php echo e($father['other']); ?><?php else: ?><?php echo e(old('other')); ?><?php endif; ?>" /></div>	
					<?php $__errorArgs = ['other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="col-md-4"></div>
						<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="nic">* National Identity Card / Passport Number</label>
				<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="National Identity Card / Passport Number" id="nic" name="nic" value="<?php if(isset($father)): ?><?php echo e($father['nic']); ?><?php else: ?><?php echo e(old('nic')); ?><?php endif; ?>" /></div>
				<?php $__errorArgs = ['nic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class = "form-group row" style="padding-bottom: 0px;">
				<label class="col-md-4 col-form-label" for="old_thomian">* Is the father an Old Thomian?</label>
				<div class="col-md-1" style="padding-top:15px"><input class="form-control" type="checkbox" id="old_thomian" name="old_thomian" value="Thomian" onchange='oldboyClick()' <?php if(isset($father) && $father['old_thomian'] == 1): ?> checked <?php elseif(old('old_thomian')): ?> checked <?php endif; ?></div>
				</div>
				<small><strong>Note:</strong> Applies to old boys of S. Thomas' College Mount Lavinia, S. Thomas' College Gurutalawa, S. Thomas' Preparatory School Kollupitiya or S. Thomas' College Bandarawela</small>
			</div>
			<div class = "form-group row" style="padding-bottom: 20px;" id="non_thomian" <?php if(isset($father)): ?> <?php if($father['old_thomian']): ?> hidden <?php endif; ?> <?php elseif(old('old_thomian')): ?> hidden <?php endif; ?>>
				<label class="col-md-4 col-form-label" for="old_school">* Enter Father's Old School</label>
				<div class="col-md-8"><input class="form-control" type="text" maxlength="100" placeholder="Enter the name of the Father's old school" id="old_school" name="old_school" value="<?php if(isset($father)): ?><?php echo e($father['old_school']); ?><?php else: ?><?php echo e(old('old_school')); ?><?php endif; ?>"/></div>
				<?php $__errorArgs = ['old_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-md-4"></div>
					<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="row">
				<div class="col-md-6 text-center"><a class="btn btn-primary btn-lg" style="margin:10px 0;" type="button" href="<?php echo e(url('application/status')); ?>">Back</a></div>
				<div class="col-md-6 text-center"><input class="btn btn-primary btn-lg" style="margin:10px 0;" type="submit" <?php if(!isset($father)): ?> value="Save Data" <?php else: ?> value="Update Data" <?php endif; ?> id="cmdSave" name="cmdSave"/></div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/application/father.blade.php ENDPATH**/ ?>