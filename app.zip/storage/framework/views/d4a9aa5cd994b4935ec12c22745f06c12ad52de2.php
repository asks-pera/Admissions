<?php $__env->startSection('year'); ?>
	- <?php echo e($year); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2>Register to purchase an Application Form for <?php echo e($year); ?> Admissions</h2><br/>
	<form method="post" action="">
		<?php echo csrf_field(); ?>
		<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<div class="text-danger"><p>This email has already been verified. please check your emails for the credentials. Please check the spam as well.</p></div>
			<div class="text-primary"><p>This error may occur if you have already submitted an application form using this portal. However, if you wish to purchase another application form having the same email address, please click <a href="<?php echo e(url('newreg?email=' . $email . '&section=' . $section)); ?>"><strong>HERE</strong></a>.</p></div>
			<div class="text-danger"><p>Please submit the first application before you click the above link, because the first application will be unavailable for edit after clicking the same.</p></div>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		<div class = "row" style="padding-bottom: 20px;">
			<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"><label for="section">* Section</label></div>
			<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12"><input style="width:100%" type="text" readonly="readonly" id="section" name="section" value="<?php echo e($section); ?>"/></div>
		</div>
		<div class = "row" style="padding-bottom: 20px;">
			<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"><label for="name">* Name of Parent</label></div>
			<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12"><input style="width:100%" type="text" maxlength="250" placeholder="Enter Name of Parent" id="name" name="name" value="<?php echo e(old('name')); ?>" /></div>
			<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"></div>
				<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12 text-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div class = "row" style="padding-bottom: 20px;">
			<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"><label for="nic">* NIC / Passport No.</label></div>
			<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12"><input style="width:100%" type="text" maxlength="20" placeholder="Enter Sri Lankan National Identiy Card Number" id="nic" name="nic" title="National Identity Card / Passport Number" value="<?php echo e(old('nic')); ?>"/></div>
			<?php $__errorArgs = ['nic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"></div>
				<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12 text-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div class = "row" style="padding-bottom: 20px;">
			<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"><label for="mobile">* Mobile Number</label></div>
			<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12"><input style="width:100%" type="text" maxlength="20" placeholder="Enter Mobile Number" id="mobile" name="mobile" value="<?php echo e(old('mobile')); ?>"/></div>
			<?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"></div>
				<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12 text-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div class = "row" style="padding-bottom: 20px;">
			<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"><label for="email">* Verified Email address</label></div>
			<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12"><input style="width:100%" type="email" maxlength="100" readonly value="<?php echo e($email); ?>"/></div>
		</div>
		<?php if($section == "Branch Schools"): ?>
			<div class = "row" style="padding-bottom: 20px;">
				<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"><label for="branch">* Select Branch</label></div>
				<div class="col-md-8"><select id="branch" name="branch" class="form-control">
						<option value="">Select Branch</option>
						<option value="S. Thomas' Preparatory School, Kollupitiya" <?php if(old('branch')=="S. Thomas' Preparatory School, Kollupitiya"): ?> selected <?php endif; ?>>S. Thomas' Preparatory School, Kollupitiya</option>
						<option value="S. Thomas' College, Gurutalawa" <?php if(old('branch')=="S. Thomas' College, Gurutalawa"): ?> selected <?php endif; ?>>S. Thomas' College, Gurutalawa</option>
						<option value="S. Thomas' College, Bandarawela" <?php if(old('branch')=="S. Thomas' College, Bandarawela"): ?> selected <?php endif; ?>>S. Thomas' College, Bandarawela</option>
					</select>
				</div>
				<?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"></div>
					<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12 text-danger"><?php echo e($message); ?></div>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
		<?php endif; ?>
		<p>Terms and conditions</p>
		<ul class="small">
			<li>I hereby certify that the particulars given above are true and correct. If they are found to be false, wrong or incorrect, I undertake to withdraw the child from S. Thomas' College, should I be requested to do so.</li>
			<li>I accept that canvassing in any form will lead to the disqualification of this application.</li>
			<li>I accept that submitting this application form does not guarantee entrance to S. Thomas' College, and that the admission process must follow its course. I will not contact the school office until I receive a feedback from the office.</li>
			<li>I accept that I will not be able to alter any information after submission, and that I have understood the admission process.</li>
			<li>I accept that the decision of S.Thomas' College shall be final and conclusive on whether to grant entrance to a child and all matters pertaining thereto and cannot be questioned</li>
			<li>I accept that this is a computer generated Application Form which does not require a physical signature</li>
		</ul>
		<div class = "row" style="padding-top: 20px;">
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-1"></div>
			<div class="col-lg-1 col-md-2 col-sm-1 col-xs-1"><input type="checkbox" id="confirm" name="confirm" /></div>
			<div class="col-lg-9 col-md-8 col-sm-9 col-xs-10"><label for="confirm">* I hereby accept and confirm the following terms and conditions</label></div>
			<?php $__errorArgs = ['confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="col-lg-3 col-md-4 col-sm-5 col-xs-12"></div>
				<div class="col-lg-9 col-md-8 col-sm-7 col-xs-12 text-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<p style="text-align:center"><input class="btn btn-primary btn-lg" type="submit" value="Register Now" id="submit" name="submit"/></p>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/application/register.blade.php ENDPATH**/ ?>