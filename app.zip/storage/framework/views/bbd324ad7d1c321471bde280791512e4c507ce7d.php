

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigation'); ?>
	<a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('application/status')); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('year'); ?>
	- <?php echo e($year); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div id="student_picture"><img src="<?php echo e(url('/uploads/' . $picture . '')); ?>" height='120' alt="" style='float:right' /></div>
	<h2>General Details</h2>
	<div class="row border border-dark rounded" style="margin:10px; padding:50px; display:block;">
		<form action="" method="post">
			<?php echo csrf_field(); ?>
			<input type="hidden" value="<?php echo e($id); ?>" name="id" />
			<?php if(($section == 'Other Grades') || ($section == 'Grade 6') || ($section == 'Branch Schools') || ($section == 'ALevels')): ?>
				<div class="form-group row pt-5" style="padding-bottom: 20px;">
					<label for="sports" class="col-md-4 col-form-label">* Sports and Games</label>
					<div class="col-md-8"><textarea class="form-control" style="height:75px" maxlength="500" placeholder="Sports and Games of the child" id="sports" name="sports"><?php if(isset($general)): ?><?php echo e($general['sports']); ?><?php else: ?><?php echo e(old('sports')); ?><?php endif; ?></textarea></div>
					<?php $__errorArgs = ['sports'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="col-md-4"></div>
						<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="form-group row pt-5" style="padding-bottom: 20px;">
					<label for="societies" class="col-md-4 col-form-label">* Clubs and Societies</label>
					<div class="col-md-8"><textarea class="form-control" style="height:75px" maxlength="500" placeholder="Clubs and Societies of the child" id="societies" name="societies"><?php if(isset($general)): ?><?php echo e($general['societies']); ?><?php else: ?><?php echo e(old('societies')); ?><?php endif; ?></textarea></div>
					<?php $__errorArgs = ['societies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="col-md-4"></div>
						<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="form-group row pt-5" style="padding-bottom: 20px;">
					<label for="other" class="col-md-4 col-form-label">* Other Achievements</label>
					<div class="col-md-8"><textarea class="form-control" style="height:75px" maxlength="500" placeholder="Other achievements of the child" id="other" name="other"><?php if(isset($general)): ?><?php echo e($general['other']); ?><?php else: ?><?php echo e(old('sports')); ?><?php endif; ?></textarea></div>
					<?php $__errorArgs = ['other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="col-md-4"></div>
						<div class="col-md-8 text-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			<?php endif; ?>
			<div class = "form-group row" style="padding-bottom: 20px;">
				<label class="col-md-4 col-form-label" for="boarding">Will you need the boarding?</label>
				<div class="col-md-8"><select id="boarding" name="boarding" class="form-control">
					<option value="">Select</option>
					<option value="Day Scholar" <?php if((isset($general)) && ($general['boarding'] == 'Day Scholar')): ?> selected <?php elseif(old('boarding')=='Day Scholar'): ?> selected <?php endif; ?>>Day Scholar - Do not require boarding</option>
					<option value="Day Boarding" <?php if((isset($general)) && ($general['boarding'] == 'Day Boarding')): ?> selected <?php elseif(old('boarding')=='Day Boarding'): ?> selected <?php endif; ?>>Day Boarding - Daily from 6.00am to 6.00pm</option>
					<option value="Full Boarding" <?php if((isset($general)) && ($general['boarding'] == 'Full Boarding')): ?> selected <?php elseif(old('boarding')=='Full Boarding'): ?> selected <?php endif; ?>>Full Boarding</option>
				</select></div>
				<?php $__errorArgs = ['boarding'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="col-md-4"></div><div class="col-md-8 text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="row">
				<div class="col-md-6 text-center"><a class="btn btn-primary btn-lg" style="margin:10px 0;" type="button" href="<?php echo e(url('application/status')); ?>">Back</a></div>
				<div class="col-md-6 text-center"><input class="btn btn-primary btn-lg" style="margin:10px 0;" type="submit" <?php if(!isset($general)): ?> value="Save Data" <?php else: ?> value="Update Data" <?php endif; ?> id="cmdSave" name="cmdSave"/></div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/application/general.blade.php ENDPATH**/ ?>