<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>S. Thomas' College - Admissions</title>
	<link id="page_favicon" href="favicon.ico?v=2" rel="icon" type="image/x-icon" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  	<link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>"  />
</head>
<body>
	<nav class="navbar fixed-top navbar-expand-lg navbar-dark blue-gradient scrolling-navbar justify-content-end" style="background-color: #335577; height:55px">
		<form action="/logout" method="post">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="guard" value="admin"/>
			<a class="btn btn-primary btn-primary" href="admin/settings">Application Settings</a>
			<button class="btn btn-primary btn-primary">Logout</button>
		</form>
    </nav>
	<div class="container-fluid header_background mt-4 pt-4">
		<div class="row" style="background-color: #88CCFF;">
			<div class="p-3 mx-auto"><img src="<?php echo e(url('images/crest2.png')); ?>" height="150" alt="crest.jpg" /></div>
			<div class="mx-auto my-auto text-center"><h1><strong>S. Thomas' College, Mount Lavinia<br/>Admissions - 2022</strong></h1></div>
		</div>
	</div>
	<div class="container-fluid body_background" >
		<?php if(session('success') !== null): ?>
			<div class="alert alert-success"><?php echo e(session('success')); ?></div>
		<?php endif; ?>
		<?php if(session('error') !== null): ?>
			<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
		<?php endif; ?>
		<?php if(session('info') !== null): ?>
			<div class="alert alert-info"><?php echo e(session('info')); ?></div>
		<?php endif; ?>
		<?php if(isset($success)): ?>
			<div class="alert alert-success"><?php echo e($success); ?></div>
		<?php endif; ?>
		<?php if(isset($error)): ?>
			<div class="alert alert-danger"><?php echo e($error); ?></div>
		<?php endif; ?>
		<?php if(isset($info)): ?>
			<div class="alert alert-info"><?php echo e($info); ?></div>
		<?php endif; ?>
		<h3 style="text-align:center">Total Registered = <?php echo e($total); ?> | Not Purchased = <?php echo e($notpurchased); ?> | Purchased Not Submitted = <?php echo e($purchased); ?> | Submitted = <?php echo e($submitted); ?></h3>
		<table border="2">
			<thead>
				<th width="20px">ID</th>
				<th width="200px">Name</th>
				<th width="50px">Mobile</th>
				<th width="100px">Email</th>
				<th width="300px">Branch</th>
				<th width="100px">Purchased</th>
				<th width="100px">Submitted</th>
				<th width="200px">Section</th>
				<th width="350px">Subjects</th>
				<th width="50px">Application</th>
			</thead>
			<?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($applicant['submitted']): ?>
					<tr style="background-color: lightgreen;">
				<?php elseif($applicant['purchased']): ?>
					<tr style="background-color: lightyellow;">
				<?php else: ?>
					<tr style="background-color: red;">
				<?php endif; ?>
						<td><?php echo e($applicant['id']); ?></td>
						<td><?php echo e($applicant['name']); ?></td>
						<td><?php echo e($applicant['mobile']); ?></td>
						<td><?php echo e($applicant['email']); ?></td>
						<td><?php echo e($applicant['branch']); ?></td>
						<td><?php if($applicant['purchased']): ?> <?php echo e($applicant['purchased_date']); ?> <?php else: ?> No <?php endif; ?></td>
						<td><?php if($applicant['submitted']): ?> <?php echo e($applicant['submitted_date']); ?> <?php else: ?> No <?php endif; ?></td>
						<?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($child['id'] == $applicant['id']): ?>
								<td><?php echo e($child['grade_sought']); ?></td>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($subject['id'] == $applicant['id']): ?>
								<td><?php echo e($subject['alsubject1']); ?><br><?php echo e($subject['alsubject2']); ?><br><?php echo e($subject['alsubject3']); ?><br><?php echo e($subject['alsubject4']); ?></td>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php if($applicant['submitted']): ?> 
							<td><a href="https://admissions.stcmount.com/uploads/<?php echo e($applicant['id']); ?>_pdf.pdf" target="blank">Application</a></td>
						<?php endif; ?>
					</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
		<form action="" method="POST">
			<?php echo csrf_field(); ?>
			<p style="text-align:center"><input class="btn btn-primary btn-primary" type="submit" value="Download Master Data"/></p>
		</form>
	</div>
</body>
</html><?php /**PATH C:\Projects\laravel\resources\views/admin/admin.blade.php ENDPATH**/ ?>