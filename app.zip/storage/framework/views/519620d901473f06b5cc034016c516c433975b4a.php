<div>
	<div style="text-align:center"><img src="https://admissions.stcmount.com/images/crest2.jpg" height="60px" /></div>
	<div style="text-align:center"><h1>S. Thomas' College, Mount, Lavinia</h1></div>
	<div style="text-align:center"><h1>Admissions <?php echo e($year); ?></h1></div>
	<p>Dear Sir / Madam,</p>
	<h2>Email Verification</h2><br/><br/>
	<p>Thank you for interest in filling an application for <?php echo e($section); ?> admission for <?php echo e($year); ?>.</p>
	<p>Please click the following link to verify the email address in order to purchase an application form for admissions.</p><br/>
	<div style="margin-left:3em">WebLink : <a href="<?php echo e($link); ?>">Verify Email Address</a></div>
	<br/>
	<p>Kind regards</p>
	<p>Admissions</p>
	<p>S. Thomas' College, Mount Lavinia</p>
	<b>This is an automated email from the S. Thomas' College, Mount Lavinia, Admissions</b>
</div>
<?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/mail/confirmemail.blade.php ENDPATH**/ ?>