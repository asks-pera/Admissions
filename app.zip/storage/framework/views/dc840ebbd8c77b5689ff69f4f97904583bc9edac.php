<?php $__env->startSection('navigation'); ?>
    <a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('admin/login')); ?>">Admin</a>
    <?php if(count($states) >0): ?>
        <a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('application/login')); ?>">Application</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('year'); ?>
    - <?php echo e(date('Y')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(isset($info)): ?>
        <div class="alert alert-info"><?php echo e($info); ?></div>
    <?php endif; ?>
    <h2 class="text-center">Admissions</h2><br/>
    <p>Admissions applications open for various grades at various times of the year.</p>
    <p>The relevant application form will be made available only during that time.</p>
    <p>Please check here regularly for the application form to be available.</p>
    <p><strong>Please note the following:-</strong>
        <ul>
            <li>Applications for admission will <strong>only</strong> be accepted if completed using this website.</li>
            <li>Canvassing in any form will lead to the disqualification of this application</li>
            <li>Please do not give anyone money for admissions. No one is authorised to collect money for College.</li>
        </ul>
    </p><br/>
    <ul>
    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><strong><?php echo e($setting['name']); ?></strong> applications for <?php echo e($setting['year']); ?> will be open from <strong><?php echo e($setting['open']); ?></strong> to <strong><?php echo e($setting['close']); ?></strong></li><br/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul><br />
    <h3>Application Forms which are open are :</h3>
    <p class="text-center">

    <?php if(count($states) == 0): ?>
        <div class="alert alert-danger text-center">ALL APPLICATIONS CLOSED</div>
    <?php else: ?>
        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a style="margin:0px 20px" href="<?php echo e(url($state['link'])); ?>" class='btn btn-primary btn-lg' style='margin:10px'><?php echo e($state['name']); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/index.blade.php ENDPATH**/ ?>