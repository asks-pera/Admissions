

<?php $__env->startSection('navigation'); ?>
	<a style="margin: 0px 10px" class="btn btn-primary btn-primary" href="<?php echo e(url('application/status')); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('year'); ?>
	- <?php echo e($year); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2>Summary</h2>
	<div class="row border border-dark rounded" style="margin:10px; padding:50px; display:block;">
		<embed src="<?php echo e(url('uploads/' . $id . '_pdf.pdf')); ?>" height="1000px" width="100%"/>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel\Admissions\resources\views/application/finalised.blade.php ENDPATH**/ ?>