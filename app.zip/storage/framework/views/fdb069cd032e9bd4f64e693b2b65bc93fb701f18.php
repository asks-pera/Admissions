

<?php $__env->startSection('navigation'); ?>
    <form action="/logout" method="post">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="guard" value="admin"/>
		<a class="btn btn-primary btn-primary" href="summary">Back</a>
		<button class="btn btn-primary btn-primary">Logout</button>
	</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h2>Select record to change</h2>
	<div style="padding-left:3em">
	<?php $__currentLoopData = $setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h3><a href="<?php echo e(route('settings.edit', $item['id'])); ?>"><?php echo e($item['name']); ?></a></h3>
		<ul>
			<li><?php echo e($item['open']); ?></li>
			<li><?php echo e($item['close']); ?></li>
		</ul>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<div style="text-align: right"><p><a href="<?php echo e(route('settings.create')); ?>">Create Item</a></p></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\laravel\resources\views/admin/settings/view.blade.php ENDPATH**/ ?>