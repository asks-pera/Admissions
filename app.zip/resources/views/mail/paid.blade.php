<div>
	<div style="text-align:center"><img src="https://admissions.stcmount.com/images/crest2.jpg" height="60px" /></div>
	<div style="text-align:center"><h1>S. Thomas' College, Mount, Lavinia</h1></div>
	<h2>Payment Receipt</h2>
	<p>Dear Mr/Mrs/Rev {{ $applicant['name'] }},</p>
	<p>This is to confirm the receipt of the payment of Rs.1,500/- for an e-application form. You may login and continue filling the application form.</p>
	<p><strong>Please note:</strong>The purchase of the e-application form or the submission of the same, does not guarantee admission to the school or an invitation for an interview.</p>
	<p>The selection process would be at the full discretion of the school and a formal feedback on the outcome of the application will be intimated accordingly to the registered email.</p><br/>
	<br/>
	<p>Kind regards</p>
	<p>Admissions</p>
	<p>S. Thomas' College, Mount Lavinia</p>
	<b>This is an automated email from the S. Thomas' College, Mount Lavinia, Admissions</b>
</div>